/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package edd.recursividadsegundoejercicio;

/**
 *
 * @author Emili
 */
public class RecursividadSegundoEjercicio {

class Nodo {
    String valor;
    Nodo siguiente;

    public Nodo(String valor) {
        this.valor = valor;
        this.siguiente = null;
    }
}

class ListaCircular {
    Nodo inicio;

    public ListaCircular() {
        this.inicio = null;
    }

    public void insertar(String valor) {
        Nodo nuevo = new Nodo(valor);
        if (inicio == null) {
            inicio = nuevo;
            nuevo.siguiente = inicio;
        } else {
            Nodo temp = inicio;
            while (temp.siguiente != inicio) {
                temp = temp.siguiente;
            }
            temp.siguiente = nuevo;
            nuevo.siguiente = inicio;
        }
    }

    public String concatenarConEspacios() {
        if (inicio == null) {
            return "";
        } else {
            return concatenarConEspaciosRecursivo(inicio);
        }
    }

    private String concatenarConEspaciosRecursivo(Nodo nodo) {
        if (nodo.siguiente == inicio) {
            return nodo.valor;
        } else {
            return nodo.valor + " " + concatenarConEspaciosRecursivo(nodo.siguiente);
        }
    }
}

public class ListaCircular {
    public void main(String[] args) {
        ListaCircular lista = new ListaCircular();
        lista.insertar("Pepe");
        lista.insertar("Manga");
        lista.insertar("Superman");

        System.out.println("Valores concatenados con espacios: " + lista.concatenarConEspacios());
    }
}
}
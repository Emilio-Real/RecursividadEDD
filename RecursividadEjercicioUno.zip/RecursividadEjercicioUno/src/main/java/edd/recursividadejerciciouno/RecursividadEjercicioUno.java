/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package edd.recursividadejerciciouno;

import java.util.Scanner;

/**
 *
 * @author Emili
 */
public class RecursividadEjercicioUno {

    public static int sumarRecursivamente(int[] arreglo, int indice) {
        if (indice < 0) {
            return 0;
        }
        return arreglo[indice] + sumarRecursivamente(arreglo, indice - 1);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingrese los elementos del arreglo (Separados por espacios por favor :D ):");
        String[] valores = scanner.nextLine().split(" ");
        int[] arreglo = new int[valores.length];
        for (int i = 0; i < valores.length; i++) {
            arreglo[i] = Integer.parseInt(valores[i]);
        }
        int resultado = sumarRecursivamente(arreglo, arreglo.length - 1);
        System.out.println("El resultado de la suma recursiva es: " + resultado);
    }
}
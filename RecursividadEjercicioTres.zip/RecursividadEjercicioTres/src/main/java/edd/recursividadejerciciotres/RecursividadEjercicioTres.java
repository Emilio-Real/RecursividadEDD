/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package edd.recursividadejerciciotres;

import java.util.Scanner;

/**
 *
 * @author Emili
 */
public class RecursividadEjercicioTres {

public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Object[] pila = new Object[10];
        int top = -1;

        System.out.println("Ingresa los valores para la pila (presiona 'Enter' para agregar elementos a la pila o escribe 'salir' para mostrarlo inversamente :3 ):");
        String entrada = scanner.nextLine();
        while (!entrada.equals("salir")) {
            try {
                int valor = Integer.parseInt(entrada);
                pila[++top] = valor;
            } catch (NumberFormatException e) {
                pila[++top] = entrada;
            }
            entrada = scanner.nextLine();
        }

        System.out.println("Valores invertidos de la pila:");
        imprimirValoresInvertidos(pila, top);
    }

    public static void imprimirValoresInvertidos(Object[] pila, int top) {
        if (top == -1) {
            return;
        } else {
            System.out.print(pila[top] + " ");
            imprimirValoresInvertidos(pila, top - 1);
        }
    }
}
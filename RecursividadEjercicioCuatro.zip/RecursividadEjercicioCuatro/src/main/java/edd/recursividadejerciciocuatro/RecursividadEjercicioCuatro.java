/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package edd.recursividadejerciciocuatro;

import java.util.Scanner;

/**
 *
 * @author Emili
 */
public class RecursividadEjercicioCuatro {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("QUe numero se desea aplicarle un factorial (!)? ");
        int numeroFactorial = scanner.nextInt();
        long factorial = calcularFactorial(numeroFactorial);
        
        System.out.print("Que numero se desea potencial? ");
        int base = scanner.nextInt();
        
        System.out.print("Y cual seria su potencia? ");
        int exponente = scanner.nextInt();
        long potencia = calcularPotencia(base, exponente);
        
        long resultado = factorial * potencia;
        System.out.println("El resultado de " + numeroFactorial + "! + " + base + "^" + exponente + " es: " + resultado);
    }

    public static long calcularFactorial(int numero) {
        if (numero == 0) {
            return 1;
        } else {
            return numero * calcularFactorial(numero - 1);
        }
    }

    public static long calcularPotencia(int base, int exponente) {
        return (long) Math.pow(base, exponente);
    }
}